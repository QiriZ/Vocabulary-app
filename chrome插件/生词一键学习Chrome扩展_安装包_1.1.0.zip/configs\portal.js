/**
 * 生词学习系统配置
 * 定义了与学习系统相关的URL和路径映射
 */

// 使用全局变量定义配置，避免ES6模块导入问题
window.portalConfig = {
  // 生词学习系统基础URL
  BASE_URL: 'http://qiri.pythonanywhere.com',
  
  // 不同功能页面的路径映射
  PATH_MAPPING: {
    default: '',      // 默认不添加路径
    review: ''        // 不添加路径
  }
};
